FAMILY 100 — BERLOMBA DALAM KEBAIKAN (VERSI ONLINE)
====================================================

Isi paket:
- index.html              = aplikasi Guru/Host + Siswa
- config.js               = konfigurasi Firebase (wajib diisi)
- database.rules.json     = aturan database awal
- SETUP_FIREBASE.txt      = panduan pemasangan
- questions.json          = bank 25 soal

FITUR:
- 25 soal
- 9 kelompok
- 10 menit
- 4 nyawa (struktur siap dikembangkan untuk penalti salah)
- Room code
- Fase menunggu sebelum game dimulai
- Host terpisah dari tampilan siswa
- Jawaban realtime
- Jawaban sama tidak mendapat poin dua kali
- Sinonim/alias dapat dipetakan
- Jawaban yang sudah ditemukan tampil, yang lain tetap tertutup
- Host dapat membuka jawaban satu per satu
- Skor realtime
- Urutan soal diacak setiap game

CATATAN PENTING:
Paket ini adalah versi deploy-ready, bukan link publik otomatis. Agar 9 HP dapat bermain
bersamaan, perlu Firebase Realtime Database dan hosting HTTPS. Ikuti SETUP_FIREBASE.txt.

Untuk produksi, ubah database.rules.json menjadi aturan yang lebih ketat. Aturan yang
disertakan dibuat sederhana agar guru dapat melakukan uji coba awal.
